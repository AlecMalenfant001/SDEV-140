#Alec Malenfant
#This program will add subtract, multiply, and divide 2 numbers entered by the user
print('Alec Malenfant \n')

num1= int(input('Enter the first integer: '))
num2= int(input('Enter the second integer: '))

print('\n' + str(num1) + ' + ' + str(num2) + ' = ' +  str(num1+num2))
print(str(num1) + ' - ' + str(num2) + ' = ' +  str(num1-num2))
print(str(num1) + ' * ' + str(num2) + ' = ' +  str(num1*num2))
print(str(num1) + ' / ' + str(num2) + ' = ' +  str(num1/num2))
 
