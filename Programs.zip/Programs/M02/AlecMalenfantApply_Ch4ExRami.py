### This Program will print the bit value for 16 bits
#Alec Malenfant
print('Alec Malenfant\n')



for x in range(16):
    print('Bit ' + str(x+1) + " = 2^" + str(x) + ' = ' + str(2**x))



